1- Para usar os testes garantir que a base de dados est� vazia (n�o usar POPULAR_TABELAS.sql)
2- Usar o CRIAR_TABELAS.sql no fim de cada teste para garantir que � feito um reset � Base de Dados para n�o influenciar os testes seguintes

TODO: Usar uma transac��o e no fim fazer rollback